package com.qbate;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import androidx.room.Database;

public class MainActivity extends AppCompatActivity {

    public static Context mainActivityContext;

    private CategoryListAdapter categoryListAdapter;
    private ArrayList<CategoryItem> categoryItemsList;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainActivityContext =this;
        listView = findViewById(R.id.category_list);
        Cursor result = new DatabaseHelper(this).getCategoryTableData();
        categoryItemsList = new ArrayList<CategoryItem>();
        while(result.moveToNext()){
            categoryItemsList.add(new CategoryItem(Integer.parseInt(result.getString(0)),
                    result.getString(1)));
        }
        categoryListAdapter = new CategoryListAdapter(this,categoryItemsList);
        listView.setAdapter(categoryListAdapter);
    }
}
