package com.qbate;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class CategoryListAdapter extends BaseAdapter {

    private Context context;
    private List<CategoryItem> categoryItems;

    public CategoryListAdapter(Context context, List<CategoryItem> categoryItems) {
        this.categoryItems = categoryItems;
        this.context = context;
    }

    @Override
    public int getCount() {
        return categoryItems.size();
    }

    @Override
    public Object getItem(int position) {
        return categoryItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return categoryItems.get(position).getCategoryId();
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View v = View.inflate(context,R.layout.category_item,null);
        TextView categoryItem = v.findViewById(R.id.category_testing);

        //setting data to the list

        categoryItem.setText("Category ID:" + categoryItems.get(position).getCategoryId()
                       + " Category Name:" + categoryItems.get(position).getCategoryName());


        //saving product id to the tag

        v.setTag(categoryItems.get(position).getCategoryId());
        return v;
    }
}
