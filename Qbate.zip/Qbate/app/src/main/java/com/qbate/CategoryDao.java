package com.qbate;

import android.icu.util.ULocale;

import com.firebase.ui.auth.data.model.User;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface CategoryDao {
    @Query("SELECT * FROM CategoryTable")
    List<CategoryTable> getAll();

    @Query("SELECT * FROM CategoryTable WHERE category_id IN (:categoryIds)")
    List<CategoryTable> loadAllByIds(int[] categoryIds);

    @Query("SELECT * FROM CategoryTable WHERE category_id LIKE :categoryId LIMIT 1")
    CategoryTable findByName(String categoryId);

    @Insert
    void insertAll(CategoryTable... categories);

    @Delete
    void delete(CategoryTable categoryId);
}
