package com.qbate;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class CategoryTable {

    @PrimaryKey
    public int category_id;

    @ColumnInfo(name = "category_name")
    public String categoryName;
}
