package com.qbate;

import com.firebase.ui.auth.data.model.User;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {CategoryTable.class}, version = 1)
public abstract class AppCategoryDatabase extends RoomDatabase {
    public abstract CategoryDao categoryDao();
}
