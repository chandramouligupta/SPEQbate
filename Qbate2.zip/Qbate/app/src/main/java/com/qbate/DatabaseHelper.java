package com.qbate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "AppLocal.db";
    public static final String TABLE_NAME = "local_category";
    public static final String COL1 = "category_id";
    public static final String COL2 = "category_name";

    public DatabaseHelper(@Nullable @android.support.annotation.Nullable Context context) {
        super(context, DATABASE_NAME,null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table " + TABLE_NAME + "(" + COL1
                 + "INTEGER PRIMARY KEY," + COL2 + " VARCHAR(30))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public boolean insertData(int categoryId, String categoryName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1,categoryId);
        contentValues.put(COL2,categoryName);
        if(db.insert(TABLE_NAME,null,contentValues) == -1)
            return false;
        return true;
    }

    public Cursor getCategoryTableData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from " + TABLE_NAME,null);
        return result;
    }
}
